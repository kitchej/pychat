class Flags:
    COUNT = 1
    DATA = 2
    DISCONNECT = 4
